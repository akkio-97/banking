from rest_framework import serializers

from banking_details.models import BankingDetails

class BankingDetailsSerializer(serializers.ModelSerializer):

    class Meta:
        model = BankingDetails
        fields = ('id', 'bank', 'ifsc', 'branch',
                  'address', 'contact', 'city', 'district', 'state'
                  )