from django.conf.urls import url, include
from django.contrib import admin
from rest_framework_simplejwt import views as jwt_views
from banking_details.views import GetBankingDetailsFromAPIView, GetBranchDetailsFromBankNameAndCityAPIView

urlpatterns = [
    # url(r'^admin/', admin.site.urls),
    url(r'^get-banking-details-by-ifsc/?', GetBankingDetailsFromAPIView.as_view()),
    url(r'^get-banking-details-by-bank-name-city/?', GetBranchDetailsFromBankNameAndCityAPIView.as_view()),

]
