# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from django.shortcuts import render
from django.conf  import settings
import logging

from  banking_details import utils  as bankig_utils
from rest_framework.response import Response
# Create your views here.

from banking_details.serializers import BankingDetailsSerializer
class GetBankingDetailsFromAPIView(APIView):
    permission_classes = (IsAuthenticated,)
    def get(self, request, *args, **kwargs):
        print "in GetBankingDetailsFromAPIView"
        user = request.user
        data  = request.GET
        ifsc_code = data.get('ifsc_code')
        print "data::",data
        print "ifsc_code::",ifsc_code
        bank_details  = bankig_utils.get_bank_details_from_ifsc(ifsc_code)
        print "bank_details", bank_details
        return Response({

            "success":True, "message": "Banks details by ifsc returned",
            "data": BankingDetailsSerializer(bank_details, many=True).data
        })



class GetBranchDetailsFromBankNameAndCityAPIView(APIView):
    permission_classes = (IsAuthenticated,)
    def get(self, request, *args, **kwargs):

        user = request.user
        data = request.GET
        bank_name = data.get('bank_name')
        city = data.get('city')
        bank_details = bankig_utils.get_branch_details_from_bank_name_and_city(bank_name, city)

        return Response({

            "success": True, "message": "Branch detaild returned.",
            "data": BankingDetailsSerializer(bank_details, many=True).data
        })