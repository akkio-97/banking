# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from banking_details.models import BankingDetails
from django.contrib import admin

# Register your models here.
class BankingDetailsAdmin(admin.ModelAdmin):

    list_display = ('id', 'bank','ifsc','branch','contact','city','district','state')
    class Meta:
        model = BankingDetails


admin.site.register(BankingDetails, BankingDetailsAdmin)