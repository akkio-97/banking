# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.
class BankingDetails(models.Model):

    id = models.AutoField(primary_key=True)
    bank = models.CharField(max_length=200)
    ifsc = models.CharField(max_length=200)
    branch = models.CharField(max_length=200)
    address = models.CharField(max_length=200)
    contact = models.CharField(max_length=200)
    city = models.CharField(max_length=200)
    district = models.CharField(max_length=200)
    state = models.CharField(max_length=200)


    # def __unicode__(self):
    #     return "ID:" + str(self.id) + str(self.bank)

