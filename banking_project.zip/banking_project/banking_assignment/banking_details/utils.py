from banking_details.models import BankingDetails



def  get_bank_details_from_ifsc(ifsc_code):

    bank_details  = BankingDetails.objects.filter(ifsc=ifsc_code)

    return bank_details



def  get_branch_details_from_bank_name_and_city(bank_name, city):

    bank_details  = BankingDetails.objects.filter(bank=bank_name, city=city)

    return bank_details